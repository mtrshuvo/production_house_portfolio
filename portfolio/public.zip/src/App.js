import logo from './logo.svg';
import './App.css';
import Home from './Component/Body/Home';

function App() {
  return (
   <Home />
  );
}

export default App;
