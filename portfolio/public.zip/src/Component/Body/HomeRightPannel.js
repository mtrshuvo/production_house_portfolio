import React from 'react'

const HomeRightPannel = () => {
  return (
    <div>HomeRightPannel</div>
  )
}

export default HomeRightPannel