import React, { useState, useRef } from "react";
import { Tab, Tabs, TabList, TabPanel } from "react-tabs";
import { PortfolioData } from "./portfolioData";
import { IoCloseOutline } from "react-icons/io5";
import { BiLoaderAlt } from "react-icons/bi";


const Portfolio = () => {

  const [modal, setModal] = useState(false);
  const [videoLoading, setVideoLoading] = useState(true);
  const [link, setLink] = useState('');
  const allimagediv = useRef()

  const [spanText, setSpanText] = useState('')
  const [tooltipTag, setToolTipTag] = useState('')

  const openModal = () => {
    setModal(!modal);
  };

  const spinner = () => {
    setVideoLoading(!videoLoading);
  };

  // useEffect(()=> {
  //   Aos.init({duration: 2000,
  //     offset: 120,

  //   })
  // },[])

  const toolTipMove = (e, title, toolTipClass) => {
    var x = e.clientX,
      y = e.clientY
    setSpanText(title)
    setToolTipTag(toolTipClass)
    console.log("ToolTip Tag",x,y);
    var finalTag = document.getElementById(`${tooltipTag}`)

    if (spanText) {
      finalTag.style.top = (y + 20) + 'px';
      finalTag.style.left = (x + 20) + 'px';
    }
  }

  return (
    <>
      {/* <SimpleReactLightbox> */}
      <div className="tokyo_tm_portfolio">
        <div className="tokyo_tm_title">
          <div className="title_flex">
            <div className="left">
              <span>Portfolio</span>
              <h3>Creative Portfolio</h3>
            </div>
          </div>
        </div>
        {/* END TOKYO_TM_TITLE */}
        <div className="portfolio_filter">
          <Tabs>
            <TabList>
              <Tab>All</Tab>
              <Tab>Fashion</Tab>
              <Tab>Commercial</Tab>
              <Tab>Industrial</Tab>
              <Tab>Documentary</Tab>
            </TabList>
            {/* END TABLIST */}
            <div className="list_wrapper">
              {/* <SRLWrapper> */}
              <TabPanel>
                <ul className="portfolio_list">
                  {
                    PortfolioData.map((val, ind) => {
                      return (
                        <li>
                          <div className="inner">
                            <div className="entry tokyo_tm_portfolio_animation_wrap" onClick={() => {
                              setLink(val.link)
                              openModal()
                            }}>
                              {modal ? (
                                <section className="modal__bg">
                                  <div className="modal__align">
                                    <div className="modal__content" modal={modal}>
                                      <IoCloseOutline
                                        className="modal__close"
                                        arial-label="Close modal"
                                        onClick={setModal}
                                      />
                                      <div className="modal__video-align embed-responsive embed-responsive-16by9">
                                        {videoLoading ? (
                                          <div className="modal__spinner">
                                            <BiLoaderAlt
                                              className="modal__spinner-style"
                                              fadein="none"
                                            />
                                          </div>
                                        ) : null}
                                        <iframe

                                          className="modal__video-style"
                                          onLoad={spinner}
                                          loading="lazy"
                                          width="800"
                                          height="500"
                                          // "https://www.youtube.com/embed/4UZrsTqkcW4"
                                          src={link}
                                          // {val.link}
                                          title={val.title}
                                          frameBorder="0"
                                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                          allowFullScreen
                                        ></iframe>
                                      </div>
                                    </div>
                                  </div>
                                </section>
                              ) : null}
                              <img
                                src={val.img}
                                alt="Portfolio"
                                style={{ cursor: 'pointer' }}
                                onMouseMove={(e) => toolTipMove(e, val.title, `tooltip${ind}`)}
                              />
                              <span  id={`tooltip${ind} tooltip`} >{spanText}</span>
                            </div>
                          </div>
                        </li>
                      )

                    })
                  }


                </ul>
                {/* END PORTFOLIO LIST */}
              </TabPanel>
              {/* END ALL PORTFOLIO GALLERY */}

              <TabPanel>
                <ul className="portfolio_list">
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/3.jpg">
                          <img
                            src="assets/img/portfolio/3.jpg"
                            alt="Ui/Ux"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END VIMEO */}
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/5.jpg">
                          <img
                            src="assets/img/portfolio/5.jpg"
                            alt="Ui/Ux"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END VIMEO */}
                </ul>
                {/* END PORTFOLIO LIST */}
              </TabPanel>
              {/* END UI/UX GALLERY */}

              <TabPanel>
                <ul className="portfolio_list">
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/2.jpg">
                          <img
                            src="assets/img/portfolio/2.jpg"
                            alt="Website"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END YOUTUBE */}
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/4.jpg">
                          <img
                            src="assets/img/portfolio/4.jpg"
                            alt="Website"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END YOUTUBE */}
                </ul>
                {/* END PORTFOLIO LIST */}
              </TabPanel>
              {/* END WEBSITE GALLERY */}

              <TabPanel>
                <ul className="portfolio_list">
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/3.jpg">
                          <img
                            src="assets/img/portfolio/3.jpg"
                            alt="Graphic"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END SOUNDCLOUD */}
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/5.jpg">
                          <img
                            src="assets/img/portfolio/5.jpg"
                            alt="Graphic"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END SOUNDCLOUD */}
                </ul>
                {/* END PORTFOLIO LIST */}
              </TabPanel>
              {/* END GRAPHIC GALLERY */}

              <TabPanel>
                <ul className="portfolio_list">
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/2.jpg">
                          <img
                            src="assets/img/portfolio/2.jpg"
                            alt="Creative"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END IMAGE */}
                  <li>
                    <div className="inner">
                      <div className="entry tokyo_tm_portfolio_animation_wrap">
                        <a href="assets/img/portfolio/3.jpg">
                          <img
                            src="assets/img/portfolio/3.jpg"
                            alt="Creative"
                          />
                        </a>
                      </div>
                    </div>
                  </li>
                  {/* END IMAGE */}
                </ul>
                {/* END PORTFOLIO LIST */}
              </TabPanel>
              {/* END CREATIVE PORTFOLIO GALLERY */}
              {/* </SRLWrapper> */}
              {/* END TABPANEL */}
            </div>
            {/* END LIST WRAPPER */}
          </Tabs>
        </div>
      </div>
      {/* </SimpleReactLightbox> */}
    </>
  );
};

export default Portfolio;
