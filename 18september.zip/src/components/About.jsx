import React, { useState } from "react";
import Modal from "react-modal";
import Brand from "./Brand";



Modal.setAppElement("#root");

const About = () => {
  const [isOpen, setIsOpen] = useState(false);

  function toggleModal() {
    setIsOpen(!isOpen);
  }

  return (
    <>
      <div className="tokyo_tm_about">
        <div className="about_image">
          <img src="assets/img/about/about.jpg" alt="about" />
        </div>
        {/* END ABOUT IMAGE */}
        <div className="description">
          <h3 className="name">Jahan Iftekhar </h3>
          <div className="description_inner">
            <div className="left">
              <p>
                With over ten years in the industry, Bangladeshi director Jahan Iftekhar is one of the most
                experienced and widely known as Fashion filmmaker. He has over 30 industry standard
                fashion films made under his planning and direction and his process of creations continues
                till date.
              </p>
              <div className="tokyo_tm_button">
                <button onClick={toggleModal} className="ib-button" style={{marginTop:"20px"}}>
                  Read More
                </button>
              </div>
              {/* END TOKYO BUTTON */}
            </div>
            {/* END LEFT */}
            <div className="right">
              <ul>
                <li>
                  <p>
                    <span>Birthday:</span>Augest 23, 1992
                  </p>
                </li>
                <li>
                  <p>
                    <span>Age:</span>31
                  </p>
                </li>
                <li>
                  <p>
                    <span>Email:</span>
                    <a href="mailto:iftekhar.zahan@gmail.com">iftekhar.zahan@gmail.com</a>
                  </p>
                </li>
                <li>
                  <p>
                    <span>Phone:</span>
                    +8801680714092
                  </p>
                </li>
                <li>
                  <p>
                    <span>Study:</span>Unversity of Liberal Arts Bangladesh
                  </p>
                </li>
                <li>
                  <p>
                    <span>Address:</span>Flat B-6, House 14/A, Road 2/2, Banani,  1213 Dhaka, Bangladesh
                  </p>
                </li>
                
                <li>
                  <p>
                    <span>Freelance:</span>Available
                  </p>
                </li>
              </ul>
              {/* END UL */}
            </div>
            {/* END RIGHT */}
          </div>
          {/* END DESCRIPTION INNER */}
        </div>
      </div>

      {/* START ABOUT POPUP BOX */}
      <Modal
        isOpen={isOpen}
        onRequestClose={toggleModal}
        contentLabel="My dialog"
        className="mymodal"
        overlayClassName="myoverlay"
        closeTimeoutMS={500}
      >
        <div className="tokyo_tm_modalbox_about">
          <button className="close-modal" onClick={toggleModal}>
            <img src="assets/img/svg/cancel.svg" alt="close icon" />
          </button>
          {/* END POPUP CLOSE BUTTON */}
          <div className="box-inner">
            <div className="description_wrap scrollable">
              {/* Read More About */}
              <p className='text-justify' style={{ fontStyle: 'italic', color: "#767676", lineHeight: '30px' }}>
                      While graduating in Media Studies and Journalism from the University of Liberal Arts (ULAB),
                      he started his career in filmmaking by creating documentary films for NGO's.
                      <span style={{
                        display: 'block',
                        marginTop: '1rem'
                      }}></span>
                      In his formative years, Jahan has worked many reputed directors and production houses. His
                      journey started in 2012 as assistant director (Casting) of Amitabh Reza Chowdhury at Half
                      Stop Down. Later on, working as an assistant director of Mezbaur Rahman Sumon in
                      Facecard Production in 2013. And then as a post-production supervisor under the director
                      Dhrubo Hassan at Outcaste Films in 2014
                      <span style={{
                        display: 'block',
                        marginTop: '1rem'
                      }}></span>
                      He is the founder and director of A2Z Films, A full-fledged production company established
                      in 2014. Under his strict supervision, A2Z Films has successfully developed many
                      documentary films, online video commercials, Industrial and corporate videos, and fashion
                      advertising campaigns.
                      <span style={{
                        display: 'block',
                        marginTop: '1rem'
                      }}></span>
                      He aims to make full-length feature films shortly, to connect the audience through the art of
                      his storytelling.

                    </p>
              {/* Read Mpore Abou END */}
              <div className="my_box">
               
                {/* END LEFT */}

                <div className="right">
                  <div className="about_title">
                    <h3>Skills</h3>
                  </div>
                  {/* END TITLE */}
                  <div className="tokyo_progress">
                    <div className="progress_inner" data-value="95">
                      <span>
                        <span className="label">Direction</span>
                        {/* <span className="number">100%</span> */}
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 100 + '%' }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="progress_inner" data-value="90">
                      <span>
                        <span className="label">Fashion Filmaking</span>
                        {/* <span className="number">90%</span> */}
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 100 + '%' }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="progress_inner" data-value="85">
                      <span>
                        <span className="label">Post Production Supervision</span>
                        {/* <span className="number">85%</span> */}
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 100 + '%' }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="progress_inner" data-value="85">
                      <span>
                        <span className="label">Cinematography</span>
                        {/* <span className="number">85%</span> */}
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 100 + '%' }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="progress_inner" data-value="85">
                      <span>
                        <span className="label">Music Composition</span>
                        {/* <span className="number">85%</span> */}
                      </span>
                      <div className="background">
                        <div className="bar">
                          <div className="bar_in" style={{ width: 100 + '%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  {/* EDN TOKYO PROGRESS */}
                </div>
                {/* END RIGHT */}
              </div>
              {/* END MYBOX */}


              <div className="partners">
                <div className="about_title">
                  <h3>Our Partners</h3>
                </div>
                <Brand />
              </div>
              {/* END PARTNER SLIDER */}
            </div>
          </div>
        </div>
      </Modal>
      {/* END ABOUT POPUP BOX */}
    </>
  );
};

export default About;
