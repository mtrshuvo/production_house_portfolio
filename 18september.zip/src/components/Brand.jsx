import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import logo1 from "../assets/img/logos/o-code.jpg"
import logo2 from "../assets/img/logos/pran.jpg"
import logo3 from "../assets/img/logos/sailor.jpg"
import logo4 from "../assets/img/logos/tagga-man.jpg"
import logo5 from "../assets/img/logos/twelve.jpg"
import logo6 from "../assets/img/logos/yellow.jpg"
import logo7 from "../assets/img/logos/zurham.jpg"


export default function SimpleSlider() {
  var settings = {
    dots: false,
    arrow: false,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    autoplay: true,
    responsive: [
      {
        breakpoint: 991,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 2,
        },
      },
    ],
  };
  return (
    <ul>
      <Slider {...settings}>
        <li className="item">
          <img src={logo1} alt="partners brand" />
        </li>
        <li className="item">
          <img src={logo2} alt="partners brand" />
        </li>
        <li className="item">
          <img src={logo3} alt="partners brand" />
        </li>
        <li className="item">
          <img src={logo4} alt="partners brand" />
        </li>
        <li className="item">
          <img src={logo5} alt="partners brand" />
        </li>
        <li className="item">
          <img src={logo6} alt="partners brand" />
        </li>
        <li className="item">
          <img src={logo7} alt="partners brand" />
        </li>
        <li className="item">
          <img src="assets/img/partners/8.png" alt="partners brand" />
        </li>
      </Slider>
    </ul>
  );
}
