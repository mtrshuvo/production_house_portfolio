import React, { useEffect, useState, useRef } from 'react'
import 'react-slideshow-image/dist/styles.css';
import {
  Button, Modal, ModalFooter,
  ModalHeader, ModalBody
} from "reactstrap"
import { Slide, SlideshowRef } from 'react-slideshow-image';

import aboutimg from "../../assets/aboutpage/about.jpg"
import logo1 from "../../assets/logos/o-code.jpg"
import logo2 from "../../assets/logos/pran.jpg"
import logo3 from "../../assets/logos/sailor.jpg"
import logo4 from "../../assets/logos/tagga-man.jpg"
import logo5 from "../../assets/logos/twelve.jpg"
import logo6 from "../../assets/logos/yellow.jpg"
import logo7 from "../../assets/logos/zurham.jpg"
import { fontWeight } from '@mui/system';

const About = () => {
  const width = window.innerWidth
  const [style, setStyle] = useState(false);
  const [modal, setModal] = useState(false);
  const [modalStyle, setModalStyle] = useState(false);
  const [size, setSize] = useState(width);

  // Toggle for Modal
  const toggle = () => {
    setModal(!modal);
    setTimeout(() => {
      setModalStyle(!modalStyle)
    }, 500)
  }
  useEffect(() => {
    setStyle(true);
  }, [])

  useEffect(() => {
    function updateSize() {
      setSize(window.innerWidth);
    }
    window.addEventListener('resize', updateSize)

    return () => window.removeEventListener("resize", updateSize)
  }, [size])


  return (
    <div className='main' style={{ overflowY: "auto" }}>
      <div className={`about-container`}
        style={{
          transform: style && 'translateX(0%)', opacity: style && '1',
          // backgroundColor: '#f8f8f8'
        }}>
        <div className={`about-continer-wrapper`}
        >
          <div className='about'>
            <div className='about-profile-img pb-4'>
              <img src={aboutimg} alt={'profile image'} />
            </div>
            <h3 style={{
              fontWeight: "700",
              fontFamily: "Montserrat"
            }}>Jahan Iftekhar</h3>
            <div className='about-details mt-4'>
              <div className='about-info'>
                <p className='text-justify'>
                  With over ten years in the industry, Bangladeshi director Jahan Iftekhar is one of the most
                  experienced and widely known as Fashion filmmaker. He has over 30 industry standard
                  fashion films made under his planning and direction and his process of creations continues
                  till date.
                  <span style={{
                    display: 'block',
                    marginTop: '1rem'
                  }}></span>
                </p>
                <button onClick={toggle}>Read More</button>
              </div>
              <div className='about-bio'>
                <ul>
                  <li>
                    <p>
                      <span>Birthday:</span>Augest 23, 1992
                    </p>
                  </li>
                  <li>
                    <p>
                      <span>Age:</span>31
                    </p>
                  </li>
                  <li>
                    <p>
                      <span>Email:</span>iftekhar.zahan@gmail.com
                    </p>
                  </li>
                  <li>
                    <p>
                      <span>Phone:</span>+8801680714092
                    </p>
                  </li>
                  <li>
                    <p>
                      <span>Study:</span>Unversity of Liberal Arts <span className='university'>Bangladesh</span>
                    </p>
                  </li>

                </ul>
              </div>
              <Modal isOpen={modal} toggle={toggle} size="lg" scrollable={true}
                style={{
                  maxWidth: '1000px',
                  maxHeight: "550px", width: '95%',
                  marginTop: "120px",
                  transition: 'all 0.3s ease',
                  // marginLeft: '0',

                }} >
                <ModalHeader
                  toggle={toggle}>
                </ModalHeader>

                <ModalBody >
                  <div className='modal-wrapper'
                    style={{
                      transition: "1s ease",
                      transform: modalStyle && 'translateX(0%)',
                      opacity: modalStyle && '1',
                    }}
                  >

                    <p className='text-justify' style={{ fontStyle: 'italic', color: "#767676", lineHeight: '30px' }}>
                      While graduating in Media Studies and Journalism from the University of Liberal Arts (ULAB),
                      he started his career in filmmaking by creating documentary films for NGO's.
                      <span style={{
                        display: 'block',
                        marginTop: '1rem'
                      }}></span>
                      In his formative years, Jahan has worked many reputed directors and production houses. His
                      journey started in 2012 as assistant director (Casting) of Amitabh Reza Chowdhury at Half
                      Stop Down. Later on, working as an assistant director of Mezbaur Rahman Sumon in
                      Facecard Production in 2013. And then as a post-production supervisor under the director
                      Dhrubo Hassan at Outcaste Films in 2014
                      <span style={{
                        display: 'block',
                        marginTop: '1rem'
                      }}></span>
                      He is the founder and director of A2Z Films, A full-fledged production company established
                      in 2014. Under his strict supervision, A2Z Films has successfully developed many
                      documentary films, online video commercials, Industrial and corporate videos, and fashion
                      advertising campaigns.
                      <span style={{
                        display: 'block',
                        marginTop: '1rem'
                      }}></span>
                      He aims to make full-length feature films shortly, to connect the audience through the art of
                      his storytelling.

                    </p>

                    {/* Skill Section */}
                    <div className='row mb-5'>
                      <div className='col-md-12 left-side-skill'>
                        <h6 className='photography-skill-text'>Skills</h6>
                        <div className='wedding-photography'>
                          <div className='wedding-photography-sub'>
                            <span className='label'>
                              Direction
                            </span>
                            
                          </div>
                          <div className="progress" style={{ height: "5px" }}>
                            <div className="progress-bar bg-dark" role="progressbar" style={{ width: "100%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>

                        <div className='lifestyle-photography'>
                          <div className='lifestyle-photography-sub'>
                            <span className='label'>
                              Fashion Filmaking
                            </span>
                            
                          </div>
                          <div className="progress" style={{ height: "5px" }}>
                            <div className="progress-bar bg-dark" role="progressbar" style={{ width: "100%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>

                        <div className='film-photography'>
                          <div className='film-photography-sub'>
                            <span className='label'>
                              Post Production Supervision
                            </span>
                            
                          </div>
                          <div className="progress" style={{ height: "5px" }}>
                            <div className="progress-bar bg-dark" role="progressbar" style={{ width: "100%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>
                        <div className='film-photography'>
                          <div className='film-photography-sub'>
                            <span className='label'>
                             Cinematography
                            </span>
                            
                          </div>
                          <div className="progress" style={{ height: "5px" }}>
                            <div className="progress-bar bg-dark" role="progressbar" style={{ width: "100%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>
                        <div className='film-photography'>
                          <div className='film-photography-sub'>
                            <span className='label'>
                             Music Composition
                            </span>
                            
                          </div>
                          <div className="progress" style={{ height: "5px" }}>
                            <div className="progress-bar bg-dark" role="progressbar" style={{ width: "100%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                          </div>
                        </div>

                      </div>
                      {/* <div className='col-md-2 middle-side-skill' >

                    </div> */}

                      {/* Right side div */}
                      {/* <div className='col-md-5 right-side-skill'>
                      <h6 className='language-skill-text'>Language Skills</h6>
                      <div className='wedding-photography'>
                        <div className='wedding-photography-sub'>
                          <span className='label'>
                            wedding Photography
                          </span>
                          <span className='number'>
                            95%
                          </span>
                        </div>
                        <div className="progress" style={{ height: "5px" }}>
                          <div className="progress-bar bg-dark" role="progressbar" style={{ width: "95%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                      </div>

                      <div className='lifestyle-photography'>
                        <div className='lifestyle-photography-sub'>
                          <span className='label'>
                            wedding Photography
                          </span>
                          <span className='number'>
                            75%
                          </span>
                        </div>
                        <div className="progress" style={{ height: "5px" }}>
                          <div className="progress-bar bg-dark" role="progressbar" style={{ width: "75%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                      </div>

                      <div className='film-photography'>
                        <div className='film-photography-sub'>
                          <span className='label'>
                            wedding Photography
                          </span>
                          <span className='number'>
                            50%
                          </span>
                        </div>
                        <div className="progress" style={{ height: "5px" }}>
                          <div className="progress-bar bg-dark" role="progressbar" style={{ width: "50%" }} aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                      </div>
                    </div> */}
                    </div>


                    {/* Our Partener Section */}
                    <span className='partner-text mb-4'>Our Partners</span>

                    <div className='flex-container-partner mt-4'>
                      <Slide style={{ width: "100%" }} slidesToScroll={1}
                        slidesToShow={size > 800 ? 4 : size > 500 ? 2 : 1}>
                        <div className='client-logo'>
                          <img src={logo1} />
                        </div>
                        <div className='client-logo'>
                          <img src={logo2} />
                        </div>
                        <div className='client-logo'>
                          <img src={logo3} />
                        </div><div className='client-logo'>
                          <img src={logo4} />
                        </div><div className='client-logo'>
                          <img src={logo5} />
                        </div>
                        <div className='client-logo'>
                          <img src={logo6} />
                        </div>
                        <div className='client-logo'>
                          <img src={logo7} />
                        </div>



                        {/* <div className='project-done'>
                <img src={first} />
              </div>
              <div className='happy-clients'>
                <img src={second} />
              </div>
              <div className='on-going'>
                <img src={first} />
              </div> */}
                      </Slide>
                    </div>
                  </div>



                </ModalBody>

              </Modal>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default About;