import codewinter from '../images/codewinter.jpg'
import tagaman from '../images/tagaman.jpg'
import sailor from '../images/sailor.jpg'
import twelvecloth from '../images/twelvecloth.jpg'
import zurhem from '../images/zurhem.jpg'


// "https://www.youtube.com/embed/4UZrsTqkcW4"
export const PortfolioData = [
    {
        title:"Code Winter Collection",
        img: codewinter,
        description:"Image"
    },
    {
        title:"Taga Man",
        img: tagaman,
        description:"Image"
    },
    {
        title:"Sailor",
        img: sailor,
        description:"Image"
    },
    {
        title:"Twelve cloth",
        img: twelvecloth,
        description:"Image"
    },
    {
        title:"Zurhem",
        img: zurhem,
        description:"Image"
    },

]