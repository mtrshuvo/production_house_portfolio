import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'

const PortfolioNav = () => {
  const navigate = useNavigate()
  const location = useLocation()
  return (
    <div style={{

    }}><span className='portfolio-title'>Portfolio</span>
      <div className='navbar-flex-container row' style={{marginBottom:"40px"}}>
        <div className='navbar-left col-12 col-lg-5'>
          <span className='navbar-title'>Creative Portfolio</span>
        </div>
        <div className='navbar-item col-12 col-lg-7 flex-wrap' id='port-nav-links'>
          <span className={location.pathname === '/portfolio' ? "actives Navbar-list" : "Navbar-list"} onClick={() => navigate('/portfolio')}>All</span>
          <span className={location.pathname === '/fashion' ? "actives Navbar-list" : "Navbar-list"} onClick={() => navigate('/fashion')}>Fashion</span>
          <span className={location.pathname === '/commercial' ? "actives Navbar-list" : "Navbar-list"} onClick={() => navigate('/commercial')}>Commercial</span>
          <span className={location.pathname === '/industrial' ? "actives Navbar-list" : "Navbar-list"} onClick={() => navigate('/industrial')}>Industrial</span>
          <span className={location.pathname === '/documentary' ? "actives Navbar-list" : "Navbar-list"} onClick={() => navigate('/documentary')}>Documentary</span>
          
        </div>

      </div></div>
  )
}

export default PortfolioNav