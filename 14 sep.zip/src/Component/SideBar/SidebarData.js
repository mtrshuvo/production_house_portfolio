import React from 'react'
import HomeIcon from '@mui/icons-material/Home';
import PersonIcon from '@mui/icons-material/Person';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import ArticleIcon from '@mui/icons-material/Article';
import MailIcon from '@mui/icons-material/Mail';
export const SidebarData = [
    {
        title:"Home",
        icon: <HomeIcon />,
        link:"/"
    },
    {
        title:"About",
        icon: <PersonIcon />,
        link:"/about"
    },
    {
        title:"Portfolio",
        icon: <BusinessCenterIcon />,
        link:"/portfolio"
    },
    {
        title:"News",
        icon: <ArticleIcon />,
        // link:"/news"
    },
    {
        title:"Contact",
        icon: <MailIcon />,
        // link:"/mail"
    },


]

